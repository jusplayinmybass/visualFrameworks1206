var json = {
    "contact1": {
        "fname": ["First Name:", "Myron"],
        "lname": ["Last Name:", "Carroll"],
        "email": ["Email:", "myronbennell@gmail.com"],
        "birth": ["Birthday:", "1974-09-14"],
        "level": ["Level:", "Advanced"],
        "skills": ["Skills To Develop:", "Sight Reading"],
        "other": ["Other Skills to Develop:", "Swag On Bass"],
        "time": ["Time:", "15"] 
    },
    "contact2": {
        "fname": ["First Name:", "Anthony"],
        "lname": ["Last Name:", "Jackson"],
        "email": ["Email:", "sessionace@gmail.com"],
        "birth": ["Birthday:", "1952-06-23"],
        "level": ["Level:", "Seasoned Professional"],
        "skills": ["Skills To Develop:", "Soloing"],
        "other": ["Other Skills to Develop:", "Not being So Opinionated"],
        "time": ["Time:", "15"] 
    },
    "contact3": {
        "fname": ["First Name:", "James"],
        "lname": ["Last Name:", "Jamerson"],
        "email": ["Email:", "funkbrother1@gmail.com"],
        "birth": ["Birthday:", "1936-01-19"],
        "level": ["Level:", "Seasoned Professional"],
        "skills": ["Skills To Develop:", "Learning Songs"],
        "other": ["Other Skills to Develop:", "Technique"],
        "time": ["Time:", "10"] 
    },
}